"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
function registerGameHandlers(io, socket) {
    const leaveGame = (payload) => __awaiter(this, void 0, void 0, function* () {
        const strGameId = String(payload.gameId);
        const strUserId = String(payload.userId);
        if (socket.rooms.has(strGameId)) {
            yield prisma.gameUsers.deleteMany({
                where: {
                    userId: payload.userId,
                    gameId: payload.gameId,
                },
            });
            socket.rooms.delete(strGameId);
            socket.to(strUserId).emit("game:user_left");
        }
    });
    const joinGame = (payload) => __awaiter(this, void 0, void 0, function* () {
        const game = yield prisma.lobbies.findFirst({
            where: {
                id: Number(payload.gameId),
            },
        });
        prisma.users.update({
            where: {
                id: Number(payload.userId),
            },
            data: {
                gameUsers: {
                    create: {
                        gameId: Number(payload.gameId),
                    },
                },
            },
        });
        if (!game)
            return;
        const strGameId = String(payload.gameId);
        socket.to(strGameId).emit("game:user_joined");
        socket.join(strGameId);
    });
    const sendMessage = (payload) => {
        const userGame = prisma.gameUsers.findFirst({
            where: {
                userId: payload.userId,
                gameId: payload.gameId
            }
        });
        if (!userGame)
            return;
        const strGameId = String(payload.gameId);
        socket.to(strGameId).emit("game:deliver_message", payload);
    };
    socket.on("game:join", joinGame);
    socket.on("game:leave", leaveGame);
    socket.on("game:send_message", sendMessage);
}
exports.default = registerGameHandlers;
//# sourceMappingURL=game.js.map