"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
function registerLobbyHandlers(io, socket) {
    const leaveAllLobbies = () => {
        console.log("a user disconnecting");
        socket.rooms.forEach((room) => {
            if (socket.id != room) {
                socket.leave(room);
                socket.to(room).emit("lobby:user_left");
            }
        });
    };
    const leaveLobby = (payload) => __awaiter(this, void 0, void 0, function* () {
        const strLobbyId = String(payload.lobbyId);
        const strUserId = String(payload.userId);
        if (socket.rooms.has(strLobbyId)) {
            yield prisma.userLobbies.deleteMany({
                where: {
                    userId: payload.userId,
                    lobbyId: payload.lobbyId,
                },
            });
            socket.rooms.delete(strLobbyId);
            socket.to(strUserId).emit("lobby:user_left");
        }
    });
    const joinLobby = (payload) => __awaiter(this, void 0, void 0, function* () {
        const lobby = yield prisma.lobbies.findFirst({
            where: {
                id: Number(payload.lobbyId),
            },
        });
        prisma.users.update({
            where: {
                id: Number(payload.userId),
            },
            data: {
                userLobbies: {
                    create: {
                        lobbyId: Number(payload.lobbyId),
                    },
                },
            },
        });
        if (!lobby)
            return;
        const strLobbyId = String(payload.lobbyId);
        socket.to(strLobbyId).emit("lobby:user_joined");
        socket.join(strLobbyId);
    });
    const sendMessage = (payload) => {
        const userLobby = prisma.userLobbies.findFirst({
            where: {
                userId: payload.userId,
                lobbyId: payload.lobbyId
            }
        });
        if (!userLobby)
            return;
        const strLobbyId = String(payload.lobbyId);
        socket.to(strLobbyId).emit("lobby:deliver_message", payload);
    };
    socket.on("lobby:join", joinLobby);
    socket.on("lobby:leave", leaveLobby);
    socket.on("disconnecting", leaveAllLobbies);
    socket.on("lobby:send_message", sendMessage);
}
exports.default = registerLobbyHandlers;
//# sourceMappingURL=lobby.js.map