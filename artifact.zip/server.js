"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("./app"));
const socket_io_1 = require("socket.io");
const http_1 = __importDefault(require("http"));
const lobby_1 = __importDefault(require("./handler/lobby"));
const game_1 = __importDefault(require("./handler/game"));
const server = http_1.default.createServer(app_1.default);
server.listen(process.env.IO_PORT);
let io = new socket_io_1.Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"],
    },
});
const onConnection = (socket) => {
    (0, lobby_1.default)(io, socket);
    (0, game_1.default)(io, socket);
};
io.on("connection", onConnection);
app_1.default.listen(process.env.PORT, () => {
    console.log(`Server listening on port ${process.env.PORT}.`);
});
//# sourceMappingURL=server.js.map