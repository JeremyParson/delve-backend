"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const defineCurrentUser_1 = __importDefault(require("./defineCurrentUser"));
const routeLog_1 = __importDefault(require("./routeLog"));
exports.default = (app) => {
    app.use(routeLog_1.default);
    app.use(defineCurrentUser_1.default);
};
//# sourceMappingURL=index.js.map