"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const runtime_1 = require("@prisma/client/runtime");
function errorHandler(err, req, res, next) {
    if (res.headersSent)
        return next(err);
    if (err instanceof runtime_1.PrismaClientKnownRequestError) {
        if (err.code == "P2019") {
            res
                .status(400)
                .json({ message: `An input error occurred: ${err.message}` });
        }
        else if (err.code == "P2025") {
            res
                .status(400)
                .json({ message: "The records you referenced do not exist." });
        }
        else if (err.code == "P1008") {
            res.status(400).json({ message: "A timeout occurred." });
        }
        else {
            res.status(500).json({ message: "An error occurred." });
            ;
        }
    }
    next(err);
}
exports.default = errorHandler;
//# sourceMappingURL=errorHandler.js.map