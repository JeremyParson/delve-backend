"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function takeTurn() {
}
exports.default = takeTurn;
//# sourceMappingURL=enemy%20behavior.js.map